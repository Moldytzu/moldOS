#include "../timer.h"

int cpuSpeed();