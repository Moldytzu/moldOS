#include "../../common/utils.h"

void WaitForKey();

int GetKey();

int InitKeyboard();

int GetKeyRaw();

void WriteKey(unsigned int color);

 int ESC_KEY = 1;
 int ONE_KEY = 2;
 int TWO_KEY = 3;
 int THREE_KEY = 4;
 int FOUR_KEY = 5;
 int FIVE_KEY = 6;
 int SIX_KEY = 7;
 int SEVEN_KEY = 8;
 int EIGHT_KEY = 9;
 int NINE_KEY = 10;
 int ZERO_KEY = 11;
 int MINUS_KEY = 12;
 int EQUALS_KEY = 13;
 int BACKSPACE_KEY = 14;
 int TAB_KEY = 15;
 int Q_KEY = 16;
 int W_KEY = 17;
 int E_KEY = 18;
 int R_KEY = 19;
 int T_KEY = 20;
 int Y_KEY = 21;
 int U_KEY = 22;
 int I_KEY = 23;
 int O_KEY = 24;
 int P_KEY = 25;
 int LBRAKET_KEY = 26;
 int RBRAKET_KEY = 27;
 int ENTER_KEY = 28;
 int RCTRL_KEY = 29;
 int A_KEY = 30;
 int S_KEY = 31;
 int D_KEY = 32;
 int F_KEY = 33;
 int G_KEY = 34;
 int H_KEY = 35;
 int J_KEY = 36;
 int K_KEY = 37;
 int L_KEY = 38;
 int TWOPOINTS_KEY = 39;
 int QUOTE_KEY = 40;
 int APOSTROPHE_KEY = 41;
 int LSHIFT_KEY = 42;
 int PIPE_KEY = 43;
 int Z_KEY = 44;
 int X_KEY = 45;
 int C_KEY = 46;
 int V_KEY = 47;
 int B_KEY = 48;
 int N_KEY = 49;
 int M_KEY = 50;
 int LANGLEBRAKET_KEY = 51;
 int RANGLEBRAKET_KEY = 52;
 int SLASH_KEY = 53;
 int RSHIFT_KEY = 54;
 int LALT_KEY = 56;
 int SPACE_KEY = 57;