void InitPower(void* PowDwn);
void Reset();
void Shutdown();