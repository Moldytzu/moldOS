#include "../../common/utils.h"

void play_sound(long long nFrequence);
void stop_sound();