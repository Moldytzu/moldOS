#include "../common/utils.h"

void Wait(int sec);
void doWait(long long int ms);
unsigned char getRTCregister(int reg);
int getRTCtime();
int getRTCsecond();
int getRTCminutes();
int getRTChours();
