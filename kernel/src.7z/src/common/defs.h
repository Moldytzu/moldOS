#define bool int
#define true 1
#define false 0