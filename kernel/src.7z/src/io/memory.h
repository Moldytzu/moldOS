#include "../common/utils.h"

int memcmp(const void* aptr,const void* bptr,int n);
int getLowMemory();